"""
Titanic Survival Analysis
Run: python src/analyze_titanic.py
Input: data/train.csv (Kaggle Titanic training dataset)
Outputs: charts and summary tables are saved in outputs/
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = ROOT / "data" / "train.csv"
OUTPUT_DIR = ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

sns.set_theme(style="whitegrid")

def load_data(path):
    if not path.exists():
        raise FileNotFoundError(
            f"Dataset not found: {path}\n"
            "Download Kaggle's Titanic train.csv and place it in the data/ folder."
        )
    df = pd.read_csv(path)
    required = {"Survived", "Pclass", "Sex", "Age", "Fare"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Dataset is missing required columns: {sorted(missing)}")
    return df

def save_chart(filename):
    plt.tight_layout()
    plt.savefig(OUTPUT_DIR / filename, dpi=150, bbox_inches="tight")
    plt.close()

def main():
    df = load_data(DATA_PATH)

    # 1. Basic inspection
    print("\\n--- DATA OVERVIEW ---")
    print(df.head())
    print("\\nShape:", df.shape)
    print("\\nColumn data types:\\n", df.dtypes)
    print("\\nMissing values:\\n", df.isnull().sum())

    # 2. Data cleaning: create analysis-ready columns without changing source data
    df["Age"] = df["Age"].fillna(df["Age"].median())
    df["Embarked"] = df["Embarked"].fillna(df["Embarked"].mode().iloc[0]) if "Embarked" in df else df.get("Embarked")
    df["Sex"] = df["Sex"].astype(str).str.strip().str.lower()
    df["Survival_Status"] = df["Survived"].map({0: "Did not survive", 1: "Survived"})

    # 3. Key metrics
    total = len(df)
    survivors = int(df["Survived"].sum())
    survival_rate = (survivors / total * 100) if total else 0
    print("\\n--- KEY METRICS ---")
    print(f"Passengers: {total}")
    print(f"Survivors: {survivors}")
    print(f"Overall survival rate: {survival_rate:.2f}%")

    summary = pd.DataFrame({
        "Metric": ["Total passengers", "Survivors", "Non-survivors", "Survival rate (%)"],
        "Value": [total, survivors, total - survivors, round(survival_rate, 2)]
    })
    summary.to_csv(OUTPUT_DIR / "key_metrics.csv", index=False)

    # 4. Survival by passenger class
    class_rates = (df.groupby("Pclass")["Survived"].mean() * 100).reset_index(name="Survival_Rate")
    class_rates.to_csv(OUTPUT_DIR / "survival_by_class.csv", index=False)
    plt.figure(figsize=(7, 5))
    plt.bar(class_rates["Pclass"].astype(str), class_rates["Survival_Rate"])
    plt.title("Survival Rate by Passenger Class")
    plt.xlabel("Passenger Class")
    plt.ylabel("Survival Rate (%)")
    save_chart("survival_by_class.png")

    # 5. Survival by gender
    gender_rates = (df.groupby("Sex")["Survived"].mean() * 100).reset_index(name="Survival_Rate")
    gender_rates.to_csv(OUTPUT_DIR / "survival_by_gender.csv", index=False)
    plt.figure(figsize=(7, 5))
    plt.bar(gender_rates["Sex"], gender_rates["Survival_Rate"])
    plt.title("Survival Rate by Gender")
    plt.xlabel("Gender")
    plt.ylabel("Survival Rate (%)")
    save_chart("survival_by_gender.png")

    # 6. Age distribution by survival status
    plt.figure(figsize=(8, 5))
    sns.histplot(data=df, x="Age", hue="Survival_Status", bins=25, kde=True, multiple="stack")
    plt.title("Passenger Age Distribution by Survival Status")
    plt.xlabel("Age")
    plt.ylabel("Passenger Count")
    save_chart("age_distribution.png")

    # 7. Fare distribution by class
    plt.figure(figsize=(8, 5))
    sns.boxplot(data=df, x="Pclass", y="Fare")
    plt.title("Fare Distribution by Passenger Class")
    plt.xlabel("Passenger Class")
    plt.ylabel("Fare")
    save_chart("fare_by_class.png")

    # 8. Correlation heatmap for numeric fields
    numeric = df.select_dtypes(include="number")
    plt.figure(figsize=(9, 6))
    sns.heatmap(numeric.corr(), annot=True, cmap="coolwarm", fmt=".2f")
    plt.title("Correlation Heatmap")
    save_chart("correlation_heatmap.png")

    print("\\n--- SURVIVAL BY CLASS ---\\n", class_rates.to_string(index=False))
    print("\\n--- SURVIVAL BY GENDER ---\\n", gender_rates.to_string(index=False))
    print(f"\\nCharts and summary CSV files saved to: {OUTPUT_DIR}")

if __name__ == "__main__":
    main()
