# Titanic Survival Analysis

## 1. Project Overview
This project performs Exploratory Data Analysis (EDA) on the Titanic passenger dataset. It explores survival patterns and compares survival rates across passenger class, gender, and age. It also examines fare distribution and relationships among numerical variables.

**Project type:** Data Analysis and Visualization  
**Language:** Python  
**Libraries:** Pandas, Matplotlib, Seaborn

## 2. Objectives
- Understand the structure and quality of the passenger dataset.
- Identify missing values and prepare the data for analysis.
- Calculate the overall survival rate.
- Compare survival rates by passenger class and gender.
- Explore age distribution by survival status.
- Visualize fare distribution and numerical correlations.

## 3. Dataset
The project uses the Kaggle Titanic competition dataset.

- Dataset page: https://www.kaggle.com/competitions/titanic/data
- Download `train.csv` from the Data tab.
- Place the downloaded file inside the project's `data/` folder, replacing the small demo file if you want the full official dataset analysis.

The repository includes a **small illustrative demo CSV** so the program can be tested immediately. It is not the full Titanic dataset and should not be used to draw historical conclusions. Use Kaggle's official `train.csv` for your final analysis and report.

Important columns:
- `Survived`: 0 = did not survive, 1 = survived
- `Pclass`: passenger class (1, 2, or 3)
- `Sex`: passenger gender as recorded in the dataset
- `Age`: passenger age
- `Fare`: ticket fare
- `SibSp` and `Parch`: family relationships aboard
- `Embarked`: port of embarkation

## 4. Project Folder Structure
```text
Titanic-Survival-Analysis/
│
├── data/
│   └── train.csv
├── outputs/
│   └── (charts and summary CSV files are generated here)
├── src/
│   └── analyze_titanic.py
├── .gitignore
├── requirements.txt
└── README.md
```

## 5. Requirements
- Python 3.9 or later
- pip
- VS Code, PyCharm, or another Python editor

## 6. Installation and Execution

### Step 1: Download or clone the repository
```bash
git clone https://github.com/YOUR-USERNAME/Titanic-Survival-Analysis.git
cd Titanic-Survival-Analysis
```

### Step 2: Create a virtual environment (recommended)
```bash
python -m venv venv
```

Activate it on Windows:
```bash
venv\Scripts\activate
```

### Step 3: Install libraries
```bash
pip install -r requirements.txt
```

### Step 4: Add the dataset
Download `train.csv` from Kaggle and save it in the `data/` folder. The file must be named `train.csv`.

### Step 5: Run the analysis
```bash
python src/analyze_titanic.py
```

## 7. Analysis and Visualizations
The Python program generates:
1. **Survival Rate by Passenger Class** – compares survival percentages for classes 1, 2, and 3.
2. **Survival Rate by Gender** – compares survival percentages across gender categories.
3. **Age Distribution by Survival Status** – displays age patterns for survivors and non-survivors.
4. **Fare Distribution by Passenger Class** – compares ticket fares across classes.
5. **Correlation Heatmap** – displays correlations among numerical columns.

It also exports:
- `outputs/key_metrics.csv`
- `outputs/survival_by_class.csv`
- `outputs/survival_by_gender.csv`

All charts are saved as PNG files in `outputs/`.

## 8. Data Cleaning
- Missing `Age` values are filled with the median age.
- Missing `Embarked` values are filled with the most frequent value when that column exists.
- Whitespace is removed from the `Sex` values and the text is converted to lowercase.
- A readable `Survival_Status` column is created for chart labels.

The original CSV file is not overwritten; cleaning is performed in memory.

## 9. Key Questions
- What percentage of passengers survived?
- How did survival rates differ by passenger class?
- How did survival rates differ by gender?
- What age patterns can be observed among survivors and non-survivors?
- How were ticket fares distributed across passenger classes?
- Which numerical variables show relationships with survival?

## 10. Conclusion
This project demonstrates a complete beginner-friendly data analysis workflow: loading data, inspecting columns, handling missing values, calculating summary metrics, grouping records, and communicating patterns through visualizations. Conclusions should be written only after running the program on the full official dataset.

## 11. Limitations
- The dataset represents a specific historical event and should not be generalized to other populations.
- Correlation does not prove causation.
- Filling missing ages with the median is a simple approach and may affect detailed age-based findings.
- The demo CSV included in this repository is only for checking that the code runs; use the full Kaggle dataset for meaningful analysis.

## 12. Author
**Name:** YOUR NAME  
**Course:** YOUR COURSE / COLLEGE  
**GitHub:** YOUR GITHUB PROFILE

## 13. References
- Kaggle Titanic Dataset: https://www.kaggle.com/competitions/titanic/data
- Pandas Documentation: https://pandas.pydata.org/docs/
- Matplotlib Documentation: https://matplotlib.org/stable/
- Seaborn Documentation: https://seaborn.pydata.org/
